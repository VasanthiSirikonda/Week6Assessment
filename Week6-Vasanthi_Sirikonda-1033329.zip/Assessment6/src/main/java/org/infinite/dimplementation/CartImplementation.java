package org.infinite.dimplementation;

import javax.persistence.Query;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.infinite.dinterface.ICart;
import org.infinite.helper.DaoHelper;
import org.infinite.pojo.Cart;

public class CartImplementation implements ICart{
	static Session sessionObj; //declaring variables
	static SessionFactory sessionFactoryObj; 
	private Configuration con;
	private Transaction t;
	public void saveData(Cart e) { //
		con = new Configuration().configure("hibernate.cfg.xml");
		sessionFactoryObj = con.buildSessionFactory();
		sessionObj = sessionFactoryObj.openSession();
		t = (Transaction) sessionObj.beginTransaction();
		sessionObj.save(e);
	}
	public void createRecord(String product_name, int price, int quantity, int subtotal,Cart ca) {
		// TODO Auto-generated method stub
		try {
			sessionObj = DaoHelper.buildSessionFactory().openSession();  //opening the session
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction(); //transaction begin
			Cart c = (Cart) sessionObj.get(Cart.class,ca.getId()); //session obj
			c.setProduct(c.getProduct()); //setting and getting the values of the properties
			c.setPrice(c.getPrice());
			c.setQuantity(c.getQuantity());
			c.setSubtotal(c.getSubtotal());
			sessionObj.update(c); //updating the session
			sessionObj.save(c);  // saving the session
			sessionObj.getTransaction().commit(); //committing the transaction
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				sessionObj.close(); //closing the session
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	public void deleteRecords() {
		// TODO Auto-generated method stub
		
		sessionObj=DaoHelper.buildSessionFactory().openSession();
		sessionObj.beginTransaction();
		Query q= sessionObj.createQuery("delete from Student where student_id=2");
		q.executeUpdate();
		
	}
	public void updateRecord() {
		// TODO Auto-generated method stub
	try{
		sessionObj=DaoHelper.buildSessionFactory().openSession();
		sessionObj.beginTransaction();
		Cart c = (Cart) sessionObj.get(Cart.class); //session obj
		c.setProduct(c.getProduct()); //setting and getting the values of the properties
		c.setPrice(c.getPrice());
		c.setQuantity(c.getQuantity());
		c.setSubtotal(c.getSubtotal());
		sessionObj.update(c); //updating the session
		sessionObj.save(c);  // saving the session
		sessionObj.getTransaction().commit(); //committing the transaction
	} catch (Exception ex) {
		ex.printStackTrace();
	} finally {
		try {
			sessionObj.close(); //closing the session
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
		
	}

}
