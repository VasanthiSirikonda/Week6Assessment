package org.infinite.dinterface;

import org.infinite.pojo.Cart;

public interface ICart {
	public void createRecord(String product_name,int price,int quantity,int subtotal,Cart ca);  //create method

	public void updateRecord(); //update method

	public void deleteRecords(); //delete method


}
