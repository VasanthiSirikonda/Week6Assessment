package org.infinite.controller;

import org.apache.log4j.Logger;
import org.infinite.dimplementation.CartImplementation;
import org.infinite.pojo.Cart;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class UpdateController {
	private static final Logger logger= Logger.getLogger(DeleteController.class); // loggers 
	private ApplicationContext con;   // declaring a variable
	@RequestMapping(value="/update",method = RequestMethod.POST)  
	public String update1(@ModelAttribute("bean") Cart e,Model m){ //mvc
		con=new ClassPathXmlApplicationContext("ApplicationContext.xml");  
		CartImplementation obj=con.getBean("dao",CartImplementation.class);
		obj.updateRecord(); //delete the records as per per request
		logger.info("Update Controller");  //logger info
		return "update";	//view page
	}

}
