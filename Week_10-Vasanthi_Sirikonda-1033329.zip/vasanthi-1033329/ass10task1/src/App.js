import React from "react";
import logo from './logo.svg';
import './App.css';

class Screen1 extends React.Component {
  render() {
    return (
      
      <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          React
        </p>
       
      </header>
      <br/><br/>
      <p1>
         <b> LOADING<br/><br/>SCREEN <br/> <br/>REACTJS</b>
        </p1>
        <br/>
        <br/>
        <img src="https://raw.githubusercontent.com/codebucks27/React-Loading-Screen/main/loader3.png" height="250" width="600" align="center"></img>
      </div>

    );
  }
}
export default Screen1;